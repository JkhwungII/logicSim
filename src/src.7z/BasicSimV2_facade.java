import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;

public class BasicSimV2_facade {
    static String baseDir = "c:/ISCAS85";
    static String CircType = "c432";
    static String testSize = "1k";
    public static void main(String[] args) throws Exception{
        String ipFile = baseDir + "/" + CircType +"_" + testSize + "_ip.txt" ;
        ArrayList<String> inputPile = new ArrayList<String>() ;
        BufferedReader br = new BufferedReader(new FileReader(ipFile)) ;
        String ipvs = "";
        int ipAmount = 0;
        while ((ipvs=br.readLine())!=null) {
            ipvs = ipvs.trim();
            inputPile.add(ipvs);
            ipAmount++;
        }
        br.close();
        //simTool(baseDir,CircType,testSize);
        Runnable r1 =()-> new BasicSimV2().BasicSim(baseDir, CircType, testSize);
        Thread t1 = new Thread(r1) ;
        t1.start();

        Runnable r2 =()-> new BasicSimV2().BasicSim(baseDir, CircType, "1m");
        Thread t2 = new Thread(r2) ;
        t2.start();

        t1.join(); t2.join();
    }
    public void gatherInput () {

    }
    /*public static void simTool(String baseDir, String CircType, String testSize){
        try {
            BasicSimV2.BasicSim(baseDir, CircType, testSize);
        } catch (Exception e){
            e.printStackTrace();
        }
    }*/
}

