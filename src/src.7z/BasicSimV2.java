import java.util.* ;
import java.io.* ;
public class BasicSimV2 {
     HashMap<String, Integer> gateValue  = new HashMap<String, Integer>() ;
     ArrayList<String> inputList = new ArrayList<String>() ;
     ArrayList<String> outputList = new ArrayList<String>() ;
     ArrayList<String[]> gateList = new ArrayList<String[]>() ;
    static String baseDir = "c:/ISCAS85";
    static String CircType = "c17";
    static String testSize = "all";
    public static void main(String[] args) throws Exception {
        // BasicSim(baseDir, CircType, testSize);
        BasicSimV2 bsim3 = new BasicSimV2() ;
        bsim3.BasicSim(baseDir,CircType,testSize);
    }
    /*public static void main(String[] args) throws Exception {
        long start = System.currentTimeMillis() ;
         String benchFile = "c:/ISCAS85/c7552.bench.txt" ;
        parseBenchFile(benchFile) ; // build data structure
        String ipFile = "c:/ISCAS85/c7552_10k_ip.txt" ;
        String opFile = "c:/ISCAS85/c7552_10k_op.txt" ;
        simulation(ipFile,opFile) ; // generate the result
        System.out.printf("Total time=%.3f sec(s)\n",
						(System.currentTimeMillis()-start)/1000.0) ;
    }*/
    public void BasicSim(String baseDir, String CircType, String testSize) {
        try {
            long start = System.currentTimeMillis() ;
            String benchFile = baseDir + "/" + CircType + ".bench.txt" ;
            parseBenchFile(benchFile) ; // build data structure
            String ipFile = baseDir + "/" + CircType +"_" + testSize + "_ip.txt" ;
            String opFile = baseDir + "/" + CircType +"_" + testSize + "_op.txt" ;
            //simulation(ipFile,opFile) ; // generate the result
            System.out.printf("Total time=%.3f sec(s)\n",
                    (System.currentTimeMillis()-start)/1000.0) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    // 模擬器函數
     /*public void simulation(String ipFile, String opFile) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(ipFile)) ;
        BufferedWriter bw = new BufferedWriter(new FileWriter(opFile)) ;
        String ipvs = "", opvs="" ;
        // 讀取輸入訊號檔案(xxx_ip.txt)，並進行邏輯閘運算，產生輸出。
        while ((ipvs=br.readLine())!=null) {
            ipvs = ipvs.trim() ; // 如"01010011"的輸入
            fillInput(ipvs) ;  // 將ipvs分解為0, 1, …，填入電路的輸入腳
            for (int i = 0 ; i<gateList.size(); i++) { // evaluate gates one by one
                doSim(gateList.get(i)) ; // 依照每個邏輯閘特性，進行運算
            }
            opvs = gatherOutput(ipvs, bw) ; // 蒐集輸出，並寫至檔案
        }
        br.close(); bw.close() ;

    }*/
     public void simulation(ArrayList<String> inputs) throws Exception {
         for (int i = 0; i < inputs.size(); i++) {
             fillInput(inputs.get(i));
             for (int j = 0 ; j<gateList.size(); j++) { // evaluate gates one by one
                 doSim(gateList.get(j)) ; // 依照每個邏輯閘特性，進行運算
             }
         }
     }

    public void fillInput(String ipvs) {
        if (ipvs.length() != inputList.size()) {
            throw new java.lang.RuntimeException("Input Size mismatch:"+ipvs.length()+","+inputList.size()) ;
        }
        for (int i = 0 ; i<ipvs.length(); i++) {
            if (ipvs.charAt(i)=='0')
                gateValue.put(inputList.get(i),0) ;
            else
                gateValue.put(inputList.get(i),1) ;
        }
    }
    // 各種邏輯閘的運算，使用if-else，效率??????
    public void doSim(String[] gateInfo) {
        String gName = gateInfo[0] ;
        String gateType = gateInfo[1] ;
        int v = 0 ;
        if (gateType.equalsIgnoreCase("AND")) {
            v = AND(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("OR")) {
            v = OR(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("NAND")) {
            v = NAND(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("NOR")) {
            v = NOR(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("XOR")) {
            v = XOR(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("XNOR")) {
            v = XNOR(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("BUF")) {
            v = BUF(gateInfo) ;
        } else if (gateType.equalsIgnoreCase("NOT")) {
            v = NOT(gateInfo) ;
        } else {
            throw new java.lang.RuntimeException("Unknown Gate:"+gName+","+gateType);
        }
        gateValue.put(gName, v) ;
    }

    /*public String gatherOutput(String ipvs, BufferedWriter bw) throws Exception {
        String opvs = "" ;
        for (int i = 0 ; i<outputList.size(); i++) {
            opvs+=gateValue.get(outputList.get(i)) ;
        }
        bw.write(ipvs+" "+opvs);
        bw.newLine();
        return opvs ;
    }*/
    public void gatherOutput(String ipvs, BufferedWriter bw) throws Exception {
        String opvs = "" ;
        for (int i = 0 ; i<outputList.size(); i++) {
            opvs+=gateValue.get(outputList.get(i)) ;
        }
    }

    // ------ Gate Value Evaluation Functions ----------
    public int AND(String[] gateInfo) {
        int v = 0 ;
        for (int i = 2 ; i<gateInfo.length; i++)
            if ( (v=gateValue.get(gateInfo[i])) ==0)
                return 0 ;
        return  1;
    }
    public int OR(String[] gateInfo) {
        int v = 0 ;
        for (int i = 2 ; i<gateInfo.length; i++)
            if ( (v=gateValue.get(gateInfo[i]))==1)
                return 1 ;
        return  0;
    }
    public int XOR(String[] gateInfo) {
        int v1 = gateValue.get(gateInfo[2]), v2 = gateValue.get(gateInfo[3]) ;
        return (v1==v2)?0:1 ;
    }
    public  int NAND(String[] gateInfo) { return (AND(gateInfo)==0)?1:0 ; }
    public  int NOR(String[] gateInfo) { return (OR(gateInfo)==0)?1:0 ;}
    public  int XNOR(String[] gateInfo) { return (XOR(gateInfo)==0)?1:0 ; }
    public  int BUF(String[] gateInfo) {return gateValue.get(gateInfo[2]);}
    public  int NOT(String[] gateInfo) { return (BUF(gateInfo)==0)?1:0 ; }

    // ------ Parsing Circuit File and Build Data Structure ----------
// ****** 暴力法讀取並切割電路檔，產生資料結構，不妥，需要修改 ******
    public void parseBenchFile(String benchFile) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(benchFile)) ;
        String aLine = "" ;
        String gName = "", gType ="" ;

        while ((aLine=br.readLine())!=null) {
            if (aLine.startsWith("#")|| aLine.trim().length()==0 ) continue ;
            if (aLine.startsWith("INPUT")) {
                String[] tt = aLine.split("\\(") ;
                gName = tt[1].replace(")","") ;
                gateValue.put(gName, null);
                inputList.add(gName) ;
            }
            else if (aLine.startsWith("OUTPUT")) {
                String[] tt = aLine.split("\\(") ;
                gName = tt[1].replace(")","") ;
                gateValue.put(gName,null) ;
                outputList.add(gName) ;
            }  else {
                aLine = aLine.replace(" ","") ;
                aLine = aLine.replace("=",",") ;
                aLine = aLine.replace("(",",") ;
                aLine = aLine.replace(")","") ;
                String[] tt = aLine.split(",") ;
                gateValue.put(tt[0], null) ;
                gateList.add(tt) ;
            }
        }
        br.close() ;
    }
}
