import java.util.* ;
import java.io.* ;
public class BasicSimV2 {
     ArrayList<ArrayList<Gate>> SGA = new ArrayList<ArrayList<Gate>>();
     ArrayList<Gate> AIG = new ArrayList<Gate>();
     ArrayList<Gate> AOG = new ArrayList<Gate>();
     ArrayList<Gate> USG = new ArrayList<Gate>();
     HashMap<String, Integer> gateValue  = new HashMap<String, Integer>();
     HashMap<String, Gate> GatesFastFind = new HashMap<String, Gate>();
     ArrayList<String> inputGateList = new ArrayList<String>() ;
     ArrayList<String> outputGateList = new ArrayList<String>() ;
     ArrayList<String[]> gateList = new ArrayList<String[]>() ;
     ArrayList<String> inputSignal = new ArrayList<String>();
     ArrayList<String> outputSignal = new ArrayList<String>();
     ArrayList<HashSet<String[]>> toSimListS = new ArrayList<HashSet<String[]>>();
     int[] currentInput;
     int[] lastInput;
    public static void main(String[] args) throws Exception {
        // BasicSim(baseDir, CircType, testSize);
        //BasicSimV2 bsim3 = new BasicSimV2() ;
        //bsim3.BasicSim(baseDir,CircType);
    }

    public void BasicSim(String baseDir, String CircType, ArrayList<String> inputSignal, boolean isUX, String Size){
        try {
            String benchFile;
            if (isUX){
                benchFile = baseDir + "/" + CircType + "_UX.bench.txt" ;
            }
            else {
                benchFile = baseDir + "/" + CircType + ".bench.txt" ;
            }
            parseBenchFile(benchFile) ; // build data
            if (isUX){
                DoLevel();
                simulation_UX(inputSignal);
            } //混亂化
            else {
                simulation(inputSignal);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void simulation(ArrayList<String> inputSignal) throws Exception {
         for (int i = 0; i < inputSignal.size(); i++) {
             fillInput(inputSignal.get(i));
             for (int j = 0 ; j<gateList.size(); j++) { // evaluate gates one by one
                 doSim(USG.get(j)) ; // 依照每個邏輯閘特性，進行運算
             }
             gatherOutput(i, inputSignal);
         }
     }
     public void simulation_UX(ArrayList<String> inputSignal) {
         for (int i = 0; i < inputSignal.size(); i++) {
             fillInput(inputSignal.get(i));
             for (int j = 1 ; j < SGA.size(); j++) {
                 ArrayList<Gate> currnetLvGates = SGA.get(j);
                for (int k = 0 ; k < currnetLvGates.size(); k++) {
                    doSim(currnetLvGates.get(k));
                }
             }
             gatherOutput(i, inputSignal);
         }
     }
    public void simulation_Reactive(ArrayList<String> inputSignal) {
        toSimListS.add(new HashSet<String[]>());
        toSimListS.add(new HashSet<String[]>());
        HashSet<String[]> doneSim = new HashSet<String[]>();
        fillInput(inputSignal.get(0));
        for (int j = 1 ; j < SGA.size(); j++) {
            ArrayList<Gate> currnetLvGates = SGA.get(j);
            for (int k = 0 ; k < currnetLvGates.size(); k++) {
                doSim(currnetLvGates.get(k));
            }
        }
        gatherOutput(0, inputSignal);
        for (int i = 1; i < inputSignal.size(); i++) {
            lastInput = currentInput;
            fillInput(inputSignal.get(i));
            for (int j = 0; j < currentInput.length; j++) {
                if (currentInput[j] != lastInput[j]) {
                    for (int k = 0; k < AIG.get(j).fatherGates.size(); k++){
                        toSimListS.get(0).add(AIG.get(j).fatherGates.get(k));
                    }
                }
            }
            for (int j = 1; j < SGA.size(); j++) {
                for (String s[] : toSimListS.get(0)) {
                    int targetLv = Integer.parseInt(s[0]);
                    if (targetLv == j) {
                        doSim(GatesFastFind.get(s[1]));
                        doneSim.add(s);
                        for (int k = 0; k < GatesFastFind.get(s[1]).fatherGates.size(); k++) {
                            toSimListS.get(1).add(GatesFastFind.get(s[1]).fatherGates.get(k));
                        }
                    }
                }
                for (String s[] : doneSim)
                    toSimListS.get(0).remove(s);
                doneSim.clear();
                toSimListS.get(0).addAll(toSimListS.get(1));
                toSimListS.get(1).clear();
            }
            gatherOutput(i, inputSignal);
        }
    }

    public void fillInput(String ipvs) {
        if (ipvs.length() != AIG.size()) {
            throw new java.lang.RuntimeException("Input Size mismatch:"+ipvs.length()+","+AIG.size()) ;
        }
        currentInput = new int [ipvs.length()];
        for (int i = 0 ; i<ipvs.length(); i++) {
            if (ipvs.charAt(i)=='0') {
                gateValue.put(AIG.get(i).Gname, 0);
                currentInput[i] = 0;
            }
            else {
                gateValue.put(AIG.get(i).Gname, 1);
                currentInput[i] = 1;
            }
        }
    }
    // 各種邏輯閘的運算，使用if-else，效率??????
    public void doSim(Gate g1) {
        String gName = g1.Gname ;
        String gateType = g1.GType.toUpperCase() ;
        int v = 0 ;
        if (gateType.equalsIgnoreCase("AND")) {
            v = AND(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("OR")) {
            v = OR(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("NAND")) {
            v = NAND(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("NOR")) {
            v = NOR(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("XOR")) {
            v = XOR(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("XNOR")) {
            v = XNOR(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("BUF")) {
            v = BUF(g1.inputGates) ;
        } else if (gateType.equalsIgnoreCase("NOT")) {
            v = NOT(g1.inputGates) ;
        } else {
            throw new java.lang.RuntimeException("Unknown Gate:"+gName+","+gateType);
        }
        gateValue.put(gName, v) ;
    }

    public void gatherOutput(int index,ArrayList<String> inputSignal) {
        String opvs = inputSignal.get(index) + " ";
        for (int i = 0 ; i<AOG.size(); i++) {
            opvs = opvs.concat(gateValue.get(AOG.get(i).Gname).toString());
        }
        outputSignal.add(opvs);
    }

    // ------ Gate Value Evaluation Functions ----------
    public int AND(ArrayList<String> gateInfo) {
        int v = 0 ;
        for (int i = 0 ; i<gateInfo.size(); i++)
            if ( (v=gateValue.get(gateInfo.get(i))) ==0)
                return 0 ;
        return  1;
    }
    public int OR(ArrayList<String> gateInfo) {
        int v = 0 ;
        for (int i = 0 ; i<gateInfo.size(); i++)
            if ( (v=gateValue.get(gateInfo.get(i)))==1)
                return 1 ;
        return  0;
    }
    public int XOR(ArrayList<String> gateInfo) {
        int v1 = gateValue.get(gateInfo.get(0)), v2 = gateValue.get(gateInfo.get(1)) ;
        return (v1==v2)?0:1 ;
    }
    public  int NAND(ArrayList<String> gateInfo) { return (AND(gateInfo)==0)?1:0 ; }
    public  int NOR(ArrayList<String> gateInfo) { return (OR(gateInfo)==0)?1:0 ;}
    public  int XNOR(ArrayList<String> gateInfo) { return (XOR(gateInfo)==0)?1:0 ; }
    public  int BUF(ArrayList<String> gateInfo) {return gateValue.get(gateInfo.get(0));}
    public  int NOT(ArrayList<String> gateInfo) { return (BUF(gateInfo)==0)?1:0 ; }

    // ------ Parsing Circuit File and Build Data Structure ----------
// ****** 暴力法讀取並切割電路檔，產生資料結構，不妥，需要修改 ******
    public void parseBenchFile(String benchFile) throws Exception {
        BufferedReader br = new BufferedReader(new FileReader(benchFile)) ;
        String aLine = "" ;
        String gName = "", gType ="" ;

        while ((aLine=br.readLine())!=null) {
            if (aLine.startsWith("#")|| aLine.trim().length()==0 ) continue ;
            if (aLine.startsWith("INPUT")) {
                String[] tt = aLine.split("\\(") ;
                gName = tt[1].replace(")","") ;
                gateValue.put(gName, null);
                Gate g1 = create_IO_gate(gName,'I');
                AIG.add(g1);
                GatesFastFind.put(gName, g1);
                inputGateList.add(gName) ;
            }
            else if (aLine.startsWith("OUTPUT")) {
                String[] tt = aLine.split("\\(") ;
                gName = tt[1].replace(")","") ;
                Gate g1 = create_IO_gate(gName,'O');
                AOG.add(g1);
                GatesFastFind.put(gName, g1);
                gateValue.put(gName,null) ;
                outputGateList.add(gName) ;
            }  else {
                ArrayList<String> inputGates = new ArrayList<String>();
                aLine = aLine.replace(" ","") ;
                aLine = aLine.replace("=",",") ;
                aLine = aLine.replace("(",",") ;
                aLine = aLine.replace(")","") ;
                String[] tt = aLine.split(",") ;
                Gate g1 = new Gate();
                for(int i = 0; i < tt.length; i++) {
                    if (i == 1) g1.GType = tt[i];
                    else {
                        if (i == 0) g1.Gname = tt[i];
                        else inputGates.add(tt[i]);
                    }
                }
                g1.createChkFlag(inputGates.size());
                g1.inputGates = inputGates;
                USG.add(g1);
                GatesFastFind.put(tt[0], g1);
                gateValue.put(tt[0], null) ;
                gateList.add(tt) ;
            }
        }
        br.close() ;
        USG.addAll(AOG);
        SGA.add(AIG);
    }

    public ArrayList createResult() {
        return outputSignal;
    }
    public Gate create_IO_gate(String Gname, char setType){
        Gate g1 = new Gate(Gname,null,null);
        g1.isLeveled = true;
        if (setType == 'O')g1.fatherGates = null;
        return g1;
    }
    public void DoLevel () {
        int leveledCnt = AOG.size(), currentLV = 1;
        while (leveledCnt < USG.size()) {
            for (int i = 0; i < USG.size(); i++) {
                Gate g1 = USG.get(i);
                if (!(g1.isLeveled)) {
                    ArrayList<String> g1InputGates = g1.inputGates;
                    ArrayList<Gate> lowerLevelGateS = SGA.get(currentLV - 1);
                    for (int j = 0; j < g1InputGates.size(); j++) {
                        if (g1.chkFlag[j]) {
                            String g1InputGate = g1InputGates.get(j);
                            for (int k = 0; k < lowerLevelGateS.size(); k++) {
                                Gate lowerLevelGate = lowerLevelGateS.get(k);
                                if (g1InputGate.equals(lowerLevelGate.Gname)) {
                                    // String[] fatherInfo = {"",g1.Gname};
                                    // lowerLevelGate.fatherGates.add(fatherInfo);
                                    g1.chkTimes++;
                                    g1.chkFlag[j] = false;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            for (int i = 0; i < USG.size(); i++) {
                Gate g1 = USG.get(i);
                if (!(g1.isLeveled)) {
                    if (g1.chkTimes == g1.inputGates.size()) {
                        ArrayList<String> g1ChildGates = g1.inputGates;
                        /*for (int j = 0; j < g1ChildGates.size(); j++){
                            Gate childGate = GatesFastFind.get(g1ChildGates.get(j));
                            for (int k = 0; k < childGate.fatherGates.size(); k++) {
                                if(childGate.fatherGates.get(k)[1] == g1.Gname) {
                                    childGate.fatherGates.get(k)[0] = Integer.toString(currentLV);
                                }
                            }
                        }*/
                        SGA.add(new ArrayList<Gate>());
                        g1.isLeveled = true;
                        g1.Glevel = currentLV - 1;
                        SGA.get(currentLV).add(g1);
                        leveledCnt++;
                    }
                }
            }
            currentLV++;
        }
    }
}
