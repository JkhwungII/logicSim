import java.io.*;
import java.util.ArrayList;
import java.util.Vector;


public class BasicSimV2_facade {
    static String baseDir = "c:/data";
    static String CircType = "c7552";
    static String testSize = "1m";
    static boolean isUX = true; // true = 混亂化 : false = 正常
    static int threadAmount;
    public static void main(String[] args) throws Exception{
        long start = System.currentTimeMillis() ;
        String ipFile = baseDir + "/" + CircType +"_" + testSize + "_ip.txt" ;
        ArrayList<String> inputPile = new ArrayList<String>() ;
        Vector finalResult = new Vector(); finalResult.setSize(inputPile.size());
        ArrayList inputThread1;
        ArrayList inputThread2;
        ArrayList inputThread3;
        ArrayList inputThread4;
        String opFile = baseDir + "/" + CircType +"_" + testSize + "_op.txt" ;
        BufferedReader br = new BufferedReader(new FileReader(ipFile)) ;
        BufferedWriter bw = new BufferedWriter(new FileWriter(opFile)) ;
        String ipvs = "";

        while ((ipvs=br.readLine())!=null) {
            ipvs = ipvs.trim();
            inputPile.add(ipvs);
        }
        br.close();
        ArrayList<ArrayList> finalOutputA = new ArrayList<ArrayList>();
        threadAmount = inputPile.size() / 4;
        inputThread1 = new ArrayList<String>(inputPile.subList(0,threadAmount));
        inputThread2 = new ArrayList<String>(inputPile.subList(threadAmount, threadAmount*2));
        inputThread3 = new ArrayList<String>(inputPile.subList(threadAmount*2, threadAmount*3));
        inputThread4 = new ArrayList<String>(inputPile.subList(threadAmount*3, inputPile.size()));
        ArrayList<String> finalInputThread = inputThread1;
        ArrayList<String> finalOutput1 = new ArrayList<>();
        Runnable r1 =()-> {
            BasicSimV2 b1 = new BasicSimV2();
            b1.BasicSim(baseDir, CircType, finalInputThread, isUX, testSize);
            finalOutput1.addAll(b1.createResult());
        };
        Thread t1 = new Thread(r1) ;
        t1.start();

        ArrayList<String> finalInputThread1 = inputThread2;
        ArrayList<String> finalOutput2 = new ArrayList<>();
        Runnable r2 =()-> {
            BasicSimV2 b2 = new BasicSimV2();
            b2.BasicSim(baseDir, CircType, finalInputThread1, isUX, testSize);
            finalOutput2.addAll(b2.createResult()) ;
            int a = threadAmount;
        };
        Thread t2 = new Thread(r2) ;
        t2.start();

        ArrayList<String> finalInputThread2 = inputThread3;
        ArrayList<String> finalOutput3 = new ArrayList<>();
        Runnable r3 =()-> {
            BasicSimV2 b3 = new BasicSimV2();
            b3.BasicSim(baseDir, CircType, finalInputThread2, isUX, testSize);
            finalOutput3.addAll(b3.createResult());
            int a = threadAmount*2;
        };
        Thread t3 = new Thread(r3) ;
        t3.start();

        ArrayList<String> finalInputThread3 = inputThread4;
        ArrayList<String> finalOutput4 = new ArrayList<>();
        Runnable r4 =()-> {
            BasicSimV2 b4 = new BasicSimV2();
            b4.BasicSim(baseDir, CircType, finalInputThread3, isUX, testSize);
            finalOutput4.addAll(b4.createResult());
            int a = threadAmount*3;
        };
        Thread t4 = new Thread(r4) ;
        t4.start();

        t1.join(); t2.join(); t3.join(); t4.join();
        finalOutputA.add(finalOutput1);
        finalOutputA.add(finalOutput2);
        finalOutputA.add(finalOutput3);
        finalOutputA.add(finalOutput4);
        produceResult(finalOutputA,bw);
        System.out.printf("Total time=%.3f sec(s)\n",
                (System.currentTimeMillis()-start)/1000.0) ;
    }
    public static void produceResult(ArrayList<ArrayList> results, BufferedWriter bw) throws IOException {
        for (int i = 0; i<results.size(); i++) {
            ArrayList<String> resultArray = results.get(i);
            for(int j = 0; j <results.get(i).size(); j++) {
                bw.write(resultArray.get(j));
                bw.newLine();
            }
        }
        bw.close();
    }
}

