import java.util.ArrayList;

public class Gate {
    public int Glevel, chkTimes = 0;
    String Gname, GType;
    boolean[] chkFlag;
    ArrayList<String> inputGates;
    ArrayList<String[]> fatherGates = new ArrayList<>();
    Boolean isLeveled = false;
    Gate(){}
    Gate(String Gname, String GType, ArrayList inputGates){
        this.Gname = Gname;
        this.Glevel = 0;
        this.GType = GType;
        this.inputGates = inputGates;
        isLeveled = false;
    }
    public void createChkFlag(int inputGateCount){
        this.chkFlag = new boolean[inputGateCount];
        for (int i = 0; i < inputGateCount; i++) this.chkFlag[i] = true;
    }
}
